import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-Menu',
    templateUrl: './mentor-Menu.component.html'
})
export class MentorMenuComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}