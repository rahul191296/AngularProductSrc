import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
flag=true;
onNotify(msg:string) : void {
       
  this.flag=false;
}
}
