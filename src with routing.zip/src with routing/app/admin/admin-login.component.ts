import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'admin-login',
    templateUrl: './admin-login.component.html'
})
export class AdminLoginComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}