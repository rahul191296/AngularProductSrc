import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { UserLoginComponent } from './user/user-login.component';
import { RouterModule } from '@angular/router';
import { MentorLoginComponent } from './mentor/mentor-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminRegisterComponent } from './admin/admin-register.component';
import { UserRegisterComponent } from './user/user-register.component';
import { MentorRegisterComponent } from './mentor/mentor-register.component';
import { UserMenuComponent } from './user/user-menu.component';
import { MentorMenuComponent } from './mentor/mentor-menu.component';



@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminLoginComponent,
    UserRegisterComponent,
    MentorRegisterComponent,
    AdminRegisterComponent,
    UserMenuComponent,
    MentorMenuComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
 RouterModule.forRoot([
  { path: 'welcome', component: WelcomeComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'mentor-login', component: MentorLoginComponent },
 { path: 'user-login', component: UserLoginComponent },
 { path: 'admin-register', component: AdminRegisterComponent },
  { path: 'mentor-register', component: MentorRegisterComponent },
 { path: 'user-register', component: UserRegisterComponent },
 { path: 'user-menu', component: UserMenuComponent },
 { path: 'trainer-menu', component: MentorMenuComponent },
  { path: '', redirectTo: 'welcome', pathMatch: 'full' },
  { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
]),
   
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
