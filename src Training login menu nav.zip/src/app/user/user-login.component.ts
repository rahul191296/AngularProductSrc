import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../login-status-service';
import { AppComponent } from '../app.component';


@Component({
    selector: 'user-login',
    templateUrl: './user-login.component.html'
})
export class UserLoginComponent implements OnInit{
    
    @Output() notify:EventEmitter <string>=new EventEmitter<string>();
    @ViewChild('f', { static: false }) loginForm: NgForm;
    userLoginStatus:boolean = false;
    routingStatus:boolean = true;
    user = {
        email: '',
        password:''
      };

   

 constructor(private loginStatusService : LoginStatusService , public callToApp : AppComponent) {

 }
  
 setLoginStatus()  {
 this. userLoginStatus = true;
 this.routingStatus = false
 this.loginStatusService. setUserLoginStatus(this.userLoginStatus);
 this.loginStatusService. setRoutingStatus(this.routingStatus);
 }
    
  onSubmit() {
   
    
    this.user.email = this.loginForm.value.email;
   
    this.user.email = this.loginForm.value.password;

    this.setLoginStatus();

    this.callToApp.fromUserLogin();
 
  }
   
  ngOnInit(): void {
    throw new Error("Method not implemented.");
}
 
  
}