import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../login-status-service';
import { AppComponent } from '../app.component';


@Component({
    selector: 'admin-login',
    templateUrl: './admin-login.component.html'
})
export class AdminLoginComponent implements OnInit{
  @ViewChild('f', { static: false }) loginForm: NgForm;
  adminLoginStatus:boolean = false;
  routingStatus:boolean = true;
    
    admin = {
        email: '',
        password:''
      };

    
    constructor(private loginStatusService : LoginStatusService , public callToApp : AppComponent) {

    }

 
setLoginStatus()  {
this.adminLoginStatus = true;
this.routingStatus = false
this.loginStatusService. setAdminLoginStatus(this.adminLoginStatus);
this.loginStatusService. setRoutingStatus(this.routingStatus);
}


    onSubmit() {
   
       
        this.admin.email = this.loginForm.value.email;
       
        this.admin.email = this.loginForm.value.password;
            
this.setLoginStatus();

this.callToApp.fromUserLogin();
      
      }

    ngOnInit(): void {
      
    }
  
}