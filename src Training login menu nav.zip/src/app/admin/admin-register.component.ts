import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'admin-register',
    templateUrl: './admin-register.component.html'
})
export class AdminRegisterComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}