import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-register',
    templateUrl: './mentor-register.component.html'
})
export class MentorRegisterComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}