import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../login-status-service';
import { AppComponent } from '../app.component';


@Component({
    selector: 'mentor-login',
    templateUrl: './mentor-login.component.html'
})
export class MentorLoginComponent implements OnInit{
  @ViewChild('f', { static: false }) loginForm: NgForm;

  
  mentorLoginStatus:boolean = false;
  routingStatus:boolean = true;
    
    mentor = {
        email: '',
        password:''
      };

      constructor(private loginStatusService : LoginStatusService , public callToApp : AppComponent) {

      }

   
setLoginStatus()  {
  this.mentorLoginStatus = true;
  this.routingStatus = false
  this.loginStatusService. setMentorLoginStatus(this.mentorLoginStatus);
  this.loginStatusService. setRoutingStatus(this.routingStatus);
  }

    onSubmit() {
        
       
        this.mentor.email = this.loginForm.value.email;
       
        this.mentor.email = this.loginForm.value.password;
        
this.setLoginStatus();

this.callToApp.fromUserLogin();

    
     
      }
    ngOnInit(): void {
      
    }
    
  
}