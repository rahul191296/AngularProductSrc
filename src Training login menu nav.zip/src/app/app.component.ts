import { Component, OnInit } from '@angular/core';
import { LoginStatusService } from './login-status-service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  userLoginStatus:boolean = false;
  adminLoginStatus:boolean = false;
  mentorLoginStatus:boolean = false;
  routingStatus:boolean = true;
  
  constructor(private loginStatusService : LoginStatusService){

  }

  fromUserLogin() {
    this.userLoginStatus = this.loginStatusService.getUserLoginStatus();
    this.adminLoginStatus = this.loginStatusService.getAdminLoginStatus();
    this.mentorLoginStatus = this.loginStatusService.getMentorLoginStatus();
    this.routingStatus = this.loginStatusService.getRoutingStatus();  
  }

  
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }
 
 
   
   
 


}
