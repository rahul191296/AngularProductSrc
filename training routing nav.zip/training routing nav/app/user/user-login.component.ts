import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../login-status-service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';


@Component({
    selector: 'user-login',
    templateUrl: './user-login.component.html'
})
export class UserLoginComponent implements OnInit{
    
   
    @ViewChild('f', { static: false }) loginForm: NgForm;
    userLoginStatus:boolean = false;
    user = {
      email: '',
      password:''
    };
    constructor(private router: Router,private loginStatusService : LoginStatusService , public callToApp : AppComponent) {

    }
     setLoginStatus()  {
     
      this.loginStatusService. setUserLoginStatus(this.userLoginStatus);
     }
 
 

    
  onSubmit() {
   
    this. userLoginStatus = true;
    this.user.email = this.loginForm.value.email;
   
    this.user.email = this.loginForm.value.password;

   
    this.setLoginStatus();

    this.callToApp.fromLogin(); 

    if(this. userLoginStatus = true ) {
      this.router.navigate(['/user-menu']);
     }
 
  }
 
  ngOnInit(): void {
    throw new Error("Method not implemented.");
}
 
  
}