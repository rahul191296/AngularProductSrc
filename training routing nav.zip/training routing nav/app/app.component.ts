import { Component, OnInit } from '@angular/core';
import { LoginStatusService } from './login-status-service';
import { SignUpStatusService } from './signUp-status-service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  userLoginStatus:boolean = false;
  adminLoginStatus:boolean = false;
  mentorLoginStatus:boolean = false;
 
  
 
  constructor(private loginStatusService : LoginStatusService , private signUpStatusService : SignUpStatusService){

  }

  fromLogin() {
    this.userLoginStatus = this.loginStatusService.getUserLoginStatus();
    this.adminLoginStatus = this.loginStatusService.getAdminLoginStatus();
    this.mentorLoginStatus = this.loginStatusService.getMentorLoginStatus();
   
  }

    ngOnInit(): void {
    throw new Error("Method not implemented.");
  }
 
 
   
   
 


}
