import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { UserLoginComponent } from './user/user-login.component';
import { RouterModule } from '@angular/router';
import { MentorLoginComponent } from './mentor/mentor-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminRegisterComponent } from './admin/admin-register.component';
import { UserRegisterComponent } from './user/user-register.component';
import { MentorRegisterComponent } from './mentor/mentor-register.component';
import { UserMenuComponent } from './user/user-menu.component';
import { MentorMenuComponent } from './mentor/mentor-menu.component';
import {FooterComponent } from './footer/footer.component';
import { AdminMenuComponent } from './admin/admin-menu.component';



@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    WelcomeComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminLoginComponent,
    UserRegisterComponent,
    MentorRegisterComponent,
    AdminRegisterComponent,
    UserMenuComponent,
    MentorMenuComponent,
    AdminMenuComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
 RouterModule.forRoot([
 
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'mentor-login', component: MentorLoginComponent },
 { path: 'user-login', component: UserLoginComponent },
 { path: 'admin-register', component: AdminRegisterComponent },
  { path: 'mentor-register', component: MentorRegisterComponent },
 { path: 'user-register', component: UserRegisterComponent },
 { path: 'user-menu', component: UserMenuComponent },
 { path: 'mentor-menu', component: MentorMenuComponent },
 { path: 'admin-menu', component: AdminMenuComponent },
 { path: '**', redirectTo: 'welcome', pathMatch: 'full' },
 { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  
]),
   
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
