import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SignUpStatusService } from '../signUp-status-service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';


@Component({
    selector: 'user-register',
    templateUrl: './user-register.component.html'
})
export class UserRegisterComponent implements OnInit{
    @ViewChild('f', { static: false }) signUpForm: NgForm;
    userSignUpStatus:boolean = false;

    user = {
        name: '',
        email: '',
        password1: '',
        password2: ''
      };

      constructor(private router : Router ) {

      }

     
           
    onSubmit() {
   
      this.userSignUpStatus = true;
        this.user.name = this.signUpForm.value.name;
       
        this.user.email = this.signUpForm.value.email;
        this.user.password1 = this.signUpForm.value.password1;
       
        this.user.password2 = this.signUpForm.value.password2;

        if(this.userSignUpStatus = true ) {
         this.router.navigate(['/user-login']);
        }
    
       
     
      }
    ngOnInit(): void {
      
    }
  
}