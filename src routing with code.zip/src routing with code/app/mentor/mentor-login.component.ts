import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-login',
    templateUrl: './mentor-login.component.html'
})
export class MentorLoginComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}