import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
flag=true;
adminClick = false;
mentorClick = false;
userClick = false;

onClickAdmin(){
  this.adminClick= true;
  this.mentorClick= false;
  this.userClick= false;
}

      onClickMentor(){
        this.mentorClick= true;
        this.adminClick= false;
        this.userClick= false;
                  }

            onClickUser(){
              this.userClick= true;
              this.mentorClick= false;
              this.adminClick= false;
                  }

onNotify(msg:string) : void {
       
  this.flag=false;
}
}
