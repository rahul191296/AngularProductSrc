import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'user-register',
    templateUrl: './user-register.component.html'
})
export class UserRegisterComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}