import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';


@Component({
    selector: 'user-login',
    templateUrl: './user-login.component.html'
})
export class UserLoginComponent implements OnInit{
    @Output() notify:EventEmitter <string>=new EventEmitter<string>();


    onClick() {
        this.notify.emit(`true`);
    }
   
   
    ngOnInit(): void {
      
    }
  
}